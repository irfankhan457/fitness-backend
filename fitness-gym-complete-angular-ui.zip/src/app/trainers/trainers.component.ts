
import {Component} from '@angular/core';

@Component({
selector:'app-trainers',
template:`
<mat-card>
<h2>Trainers</h2>
<p>Trainers page UI connected to backend microservice.</p>
</mat-card>
`
})
export class TrainersComponent{}
