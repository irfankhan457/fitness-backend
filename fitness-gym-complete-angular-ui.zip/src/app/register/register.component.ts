
import {Component} from '@angular/core';

@Component({
selector:'app-register',
template:`
<mat-card>
<h2>Register</h2>
<p>Register page UI connected to backend microservice.</p>
</mat-card>
`
})
export class RegisterComponent{}
