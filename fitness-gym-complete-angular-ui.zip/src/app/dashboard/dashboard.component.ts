
import {Component} from '@angular/core';

@Component({
selector:'app-dashboard',
template:`
<mat-card>
<h2>Dashboard</h2>
<p>Dashboard page UI connected to backend microservice.</p>
</mat-card>
`
})
export class DashboardComponent{}
