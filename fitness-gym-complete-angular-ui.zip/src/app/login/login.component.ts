
import {Component} from '@angular/core';

@Component({
selector:'app-login',
template:`
<mat-card>
<h2>Login</h2>
<p>Login page UI connected to backend microservice.</p>
</mat-card>
`
})
export class LoginComponent{}
