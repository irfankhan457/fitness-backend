
import {Component} from '@angular/core';

@Component({
selector:'app-booking',
template:`
<mat-card>
<h2>Booking</h2>
<p>Booking page UI connected to backend microservice.</p>
</mat-card>
`
})
export class BookingComponent{}
