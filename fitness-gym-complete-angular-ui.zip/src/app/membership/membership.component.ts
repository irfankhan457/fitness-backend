
import {Component} from '@angular/core';

@Component({
selector:'app-membership',
template:`
<mat-card>
<h2>Membership</h2>
<p>Membership page UI connected to backend microservice.</p>
</mat-card>
`
})
export class MembershipComponent{}
