
import {Component} from '@angular/core';

@Component({
selector:'app-payments',
template:`
<mat-card>
<h2>Payments</h2>
<p>Payments page UI connected to backend microservice.</p>
</mat-card>
`
})
export class PaymentsComponent{}
