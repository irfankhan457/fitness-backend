
import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';

import { MatToolbarModule } from '@angular/material/toolbar';
import { MatButtonModule } from '@angular/material/button';
import { MatCardModule } from '@angular/material/card';
import { MatInputModule } from '@angular/material/input';

import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { DashboardComponent } from './dashboard/dashboard.component';

@NgModule({
 declarations:[AppComponent,LoginComponent,RegisterComponent,DashboardComponent],
 imports:[
 BrowserModule,
 BrowserAnimationsModule,
 HttpClientModule,
 FormsModule,
 MatToolbarModule,
 MatButtonModule,
 MatCardModule,
 MatInputModule,
 RouterModule.forRoot([
 {path:'',component:LoginComponent},
 {path:'register',component:RegisterComponent},
 {path:'dashboard',component:DashboardComponent}
 ])
 ],
 bootstrap:[AppComponent]
})
export class AppModule{}
