
import { Component } from '@angular/core';

@Component({
 selector:'app-dashboard',
 template:`
 <mat-card>
 <h2>Gym Dashboard</h2>
 <p>Membership, Trainers, Booking modules will appear here.</p>
 </mat-card>
 `
})
export class DashboardComponent{}
